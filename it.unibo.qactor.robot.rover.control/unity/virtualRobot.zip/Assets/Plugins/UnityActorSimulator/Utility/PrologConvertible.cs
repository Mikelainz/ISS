﻿namespace UnityActorSimulator
{

    public interface PrologConvertible
    {
        string GetPrologRepresentation();
    }

}