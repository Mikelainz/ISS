%====================================================================================
% Context ctxRadar standalone= SYSTEM-configuration: file it.unibo.ctxRadar.radarOtherSensors.pl 
%====================================================================================
context(ctxradar, "localhost",  "TCP", "8080" ).  		 
%%% -------------------------------------------
