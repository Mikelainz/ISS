%====================================================================================
% Context ctxRadar standalone= SYSTEM-configuration: file it.unibo.ctxRadar.sonarSensorEmitter.pl 
%====================================================================================
context(ctxradar, "localhost",  "TCP", "8033" ).  		 
%%% -------------------------------------------
